from services.prima_pizza.app import app
